export interface IRegisterData {
  name: string;
  description: string;
  latitude: string;
  longitude: string;
  difficulty: string;
  lengthRate: string;
  rating: string;
}