export interface IRequestOptions {
  headers: { 'Content-Type': string },
  data: string | undefined | object
}